from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):

    def __init__(self, username, password):

        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31822
        DB = 'aac'
        COL = 'animals'
 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):
        if data is not None:
            result = self.database.animals.insert_one(data) 
            print("Document created: " + str(self.database.animals.find_one(data)))     
            return result    
        else:
            raise Exception("Nothing to save, data parameter is empty")

    def read(self, data):
        List = []
        for document in self.database.animals.find(data):
            List.append(document)
        if len(List) == 0:
            raise Exception("None Found")
        return List
    
    def update(self, data, updateData):
        set_data= {"$set": updateData}
        if data is not None:
            result = self.database.animals.update_many(data, set_data)
            print("Document(s) matched: " + str(result.matched_count))
            print("Document(s) updated: " + str(result.modified_count))
            return result.modified_count
        else:
            raise Exception("No documents to update")
            
    def remove(self, data):
        if data is not None:
            result = self.database.animals.delete_many(data)
            print("Document(s) deleted: " + str(result.deleted_count))
            return result.deleted_count
        else:
            raise Exception("No documents to delete")
            
