//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Shayla Vincent
// Version     :
// Copyright   : Your copyright notice
// Description : ProjectTwo, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;


struct Course {
    string courseId; // unique identifier
    string title;
    string preReq1;
    string preReq2;
};

// Internal structure for tree node
struct Node {
    Course course;
    Node *left;
    Node *right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a course
    Node(Course aCourse) :
            Node() {
        course = aCourse;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class ProjectTwo{

private:
	Node* root;

	void addNode(Node* node, Course course);
	void inOrder(Node* node);

public:
	ProjectTwo();
	void InOrder();
	void Insert(Course course);
	Course Search(string courseId);

};

//constructor
ProjectTwo::ProjectTwo(){
	root = nullptr;
}

//method to order them when printing
void ProjectTwo::InOrder(){
	inOrder(root);
}

//insert method
void ProjectTwo::Insert(Course course){
	Node* insertNode = new Node(course);

	if(root == nullptr){
		root = insertNode;
		insertNode -> left = nullptr;
		insertNode -> right = nullptr;
	}
	else{
		addNode(root, course);
	}
}

//search for one course
Course ProjectTwo::Search(string courseId){
	 // set current node equal to root
		Node* currNode = new Node();
		currNode = root;
	    // keep looping downwards until bottom reached or matching courseId found
	        // if match found, return current course
		while(currNode != nullptr){
			if(currNode->course.courseId.compare(courseId)==0){
				return currNode ->course;
			}
			else if(currNode->course.courseId.compare(courseId)<0){
				currNode = currNode -> right;
			}
			else{
				currNode = currNode -> left;
			}
		}
	        // if course is smaller than current node then traverse left
	        // else larger so traverse right
	    Course course;
	    return course;
}

//add a node to the tree
void ProjectTwo::addNode(Node* node, Course course){
	Node* newNode = new Node(course);
    // if node is larger then add to left
		if(node->course.courseId.compare(course.courseId)> 0){
			 // if no left node
			if(node->left == nullptr){
				// this node becomes left
				node-> left = newNode;
			}
			 // else recurse down the left node
			else{
				addNode(node->left, course);
			}
		}
		// else
		else{
			// if no right node
			if(node-> right ==nullptr){
				// this node becomes right
				node-> right = newNode;
			}
			 //else
			else{
				// recurse down the left node
				addNode(node-> right, course);
			}
		}
}

//helper inOrder
void ProjectTwo::inOrder(Node* node){
	 //if node is not equal to null ptr
		if (node != nullptr){
			//InOrder to the left
			inOrder(node -> left);

			//output courseID, title, amount, fund

			cout<< node->course.courseId <<", "<< node->course.title;

			if(!node -> course.preReq1.empty()&&!node -> course.preReq2.empty()){
				cout<<", " << node->course.preReq1<<", " << node->course.preReq2 << endl;
			}
			else if (!node -> course.preReq1.empty()){
				cout<<", " << node->course.preReq1<< endl;
			}

			//InOrder to the right
			inOrder(node-> right);

		}

}

void loadCourses(string fileName, ProjectTwo* bst){
	ifstream file;
	file.open(fileName);
	//make sure file opens
	if(!file.is_open()){
		cout<<"File did not open";
		return;
	}

	string courseId;
	string title;
	string preReq1;
	string preReq2;
	string line;

	while(getline(file, line)){
		Course course;
		stringstream ss(line);
		getline(ss, courseId, ',');
		course.courseId = courseId;
		getline(ss, title, ',');
		course.title = title;
		if(getline(ss,preReq1,',')){
			course.preReq1 = preReq1;
		}
		if(getline(ss, preReq2, ',')){
			course.preReq2 = preReq2;
		}

		bst-> Insert(course);
	}
	//information is stored in the tree so the file can be closed
	file.close();

}

void displayCourse(Course course) {
	cout<< course.courseId <<" | "<< course.title;

				if(!course.preReq1.empty()&&!course.preReq2.empty()){
					cout<<" | " << course.preReq1<<" | " << course.preReq2 << endl;
				}
				else if (!course.preReq1.empty()){
					cout<<" | " << course.preReq1<< endl;
				}

    return;
}


int main() {
	ProjectTwo* bst;
	bst = new ProjectTwo();
	Course course;
	string courseFind;

	int choice = 0;
	    while (choice != 9) {
	        cout << "Welcome to the course planner" << endl;
	        cout << "  1. Load Data Structure" << endl;
	        cout << "  2. Print Course List" << endl;
	        cout << "  3. Print Course" << endl;
	        cout << "  9. Exit" << endl;
	        cout << "Enter choice: ";
	        cin >> choice;

	        switch (choice) {

	        default:
	        	cout<<"Not a valid option"<<endl;
	        	break;

	        case 1:
	        	loadCourses("ABCU_Advising_Program_Input.txt", bst);
	        	break;

	        case 2:
	        	bst->InOrder();
	        	break;

	        case 3:

	        	cout<< "Please enter course ID" <<endl;
	        	cin>>courseFind;
	        	course = bst->Search(courseFind);

	        	 if (!course.courseId.empty()) {
	        		 displayCourse(course);
	        	 }
	        	 else {
	        		 cout << "Course Id " << courseFind << " not found." << endl;
	        	 }
	        	 break;

	        case 9:
	        	cout<< "Successfully closed!"<<endl;
	        	return 0;
	        	break;
	        }
	    }


	cout<<"Thank you for using the course planner!"<<endl;
	return 0;
}
